#Download tutorial
step 1 - Disable your antivirus its can be cause problems in injection.
step 2 - Start "TrianityBootstrapperV0.3.0.exe"
step 3 - after download Go to "Assets" folder and extract all of them.
step 4 - after extracting Start "445e-1435-1244-2354-7a45.exe"
step 5 - Create new tab
step 6 - Open roblox and click "inject" button
step 7 - join the game.
step 8 - after fully loading paste your script and click "Execute" button
now its working.

--- causing errors?
Please join our discord server
discord.gg/t8VYa6bUJ7 or click discord button in 445e-1435-1244-2354-7a45.exe

-- thanks for using our exploit!

-- Bootstrapper instantly closing? try to delete "Assets" folder and it should be fixed.

Translate
#Туториал на скачку
шаг 1 - отключите свой антивирус это может вызывать проблемы при инжекте.
шаг 2 - запустите "TrianityBootstrapperV0.3.0.exe"
шаг 3 - после скачки зайдите в папку "Assets" и распакуйте все что там есть.
шаг 4 - после распаковки архива запустите "445e-1435-1244-2354-7a45.exe"
шаг 5 - Создайте новый таб.
шаг 6 - откройте роблокс и кликните "Inject" кнопку.
шаг 7 - зайдите в игру.
шаг 8 - после полной загрузки вставьте скрипт и нажмите кнопку "Execute"
готово!

появляются ошибки?
зайдите в наш дискорд сервер.
discord.gg/t8VYa6bUJ7 или кликните дискорд иконку в 445e-1435-1244-2354-7a45.exe

-- спасибо за использование нашего эксплоита!

-- загрузчик сразу закрывается? попробуйте удалить "Assets" папку и это должно починиться.

